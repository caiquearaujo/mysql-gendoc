
var ApiGen = ApiGen || {};
ApiGen.elements = [["f","ajust_class_name()"],["c","AppLocale"],["f","autoload_classes()"],["c","ColumnModel"],["c","Components"],["c","ConnectController"],["c","Controller"],["c","DatabaseSchemaModel"],["c","DocumentationController"],["c","DocumentationModel"],["c","FilesController"],["c","ForeignModel"],["c","FromDBInterface"],["c","FromDBModel"],["f","get_url()"],["f","has_value()"],["c","KeyModel"],["c","Model"],["c","MyGD"],["c","PagesController"],["f","sec_session_start()"],["c","Status"],["c","TableModel"],["c","Template"],["f","translate()"]];
